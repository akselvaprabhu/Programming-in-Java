import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Member entity representing a registered patron in the library.
 * Demonstrates Inheritance (extends Person), Encapsulation, Polymorphism,
 * and uses Collections Framework (HashSet, HashMap).
 */
public class Member extends Person {
    public static final int DEFAULT_BORROW_LIMIT = 3;
    
    // Set of borrowed book IDs using HashSet
    private final Set<String> borrowedBookIds;
    // Map of book ID to issue date for fine calculations
    private final Map<String, LocalDate> issueDates;
    private int maxBorrowLimit;
    private double totalFines;

    /**
     * Default constructor.
     */
    public Member() {
        super();
        this.borrowedBookIds = new HashSet<>();
        this.issueDates = new HashMap<>();
        this.maxBorrowLimit = DEFAULT_BORROW_LIMIT;
        this.totalFines = 0.0;
    }

    /**
     * Parameterized constructor.
     * @param memberId Unique Member ID.
     * @param name Member's Full Name.
     * @param email Contact Email.
     * @param phone Contact Phone.
     */
    public Member(String memberId, String name, String email, String phone) {
        super(memberId, name, email, phone);
        this.borrowedBookIds = new HashSet<>();
        this.issueDates = new HashMap<>();
        this.maxBorrowLimit = DEFAULT_BORROW_LIMIT;
        this.totalFines = 0.0;
    }

    /**
     * Overloaded constructor with custom borrow limit.
     */
    public Member(String memberId, String name, String email, String phone, int maxBorrowLimit) {
        super(memberId, name, email, phone);
        this.borrowedBookIds = new HashSet<>();
        this.issueDates = new HashMap<>();
        this.maxBorrowLimit = maxBorrowLimit > 0 ? maxBorrowLimit : DEFAULT_BORROW_LIMIT;
        this.totalFines = 0.0;
    }

    @Override
    public String getRole() {
        return "Library Member";
    }

    /**
     * Checks if the member has reached their borrowing limit.
     * @return true if member can borrow more books, false otherwise.
     */
    public boolean canBorrow() {
        return borrowedBookIds.size() < maxBorrowLimit;
    }

    /**
     * Registers a book borrow transaction for this member.
     * @param bookId The ID of the book being borrowed.
     * @param issueDate The date of issue.
     * @return true if successful, false if limit exceeded or already borrowed.
     */
    public boolean borrowBook(String bookId, LocalDate issueDate) {
        if (!canBorrow() || borrowedBookIds.contains(bookId)) {
            return false;
        }
        borrowedBookIds.add(bookId);
        issueDates.put(bookId, issueDate);
        return true;
    }

    /**
     * Returns a book borrowed by this member.
     * @param bookId The ID of the book being returned.
     * @return Issue date if found and removed, null otherwise.
     */
    public LocalDate returnBook(String bookId) {
        if (borrowedBookIds.remove(bookId)) {
            return issueDates.remove(bookId);
        }
        return null;
    }

    /**
     * Retrieves the issue date of a currently borrowed book.
     */
    public LocalDate getIssueDate(String bookId) {
        return issueDates.get(bookId);
    }

    public Set<String> getBorrowedBookIds() {
        return Collections.unmodifiableSet(borrowedBookIds);
    }

    public int getBorrowedCount() {
        return borrowedBookIds.size();
    }

    public int getMaxBorrowLimit() {
        return maxBorrowLimit;
    }

    public void setMaxBorrowLimit(int maxBorrowLimit) {
        if (maxBorrowLimit > 0) {
            this.maxBorrowLimit = maxBorrowLimit;
        }
    }

    public double getTotalFines() {
        return totalFines;
    }

    public void addFine(double amount) {
        if (amount > 0) {
            this.totalFines += amount;
        }
    }

    public boolean payFine(double amount) {
        if (amount <= 0 || amount > this.totalFines) {
            return false;
        }
        this.totalFines -= amount;
        return true;
    }

    @Override
    public void displayDetails() {
        System.out.println("------------------------------------------------------------");
        System.out.println("Member ID:       " + getId());
        System.out.println("Name:            " + getName());
        System.out.println("Email:           " + getEmail());
        System.out.println("Phone:           " + getPhone());
        System.out.println("Role:            " + getRole());
        System.out.println("Borrowed Books:  " + borrowedBookIds.size() + "/" + maxBorrowLimit + " " + borrowedBookIds);
        System.out.printf("Outstanding Fine: $%.2f%n", totalFines);
        System.out.println("------------------------------------------------------------");
    }

    @Override
    public String toString() {
        return String.format("%s | Borrowed: %d/%d | Fines: $%.2f",
                super.toString(), borrowedBookIds.size(), maxBorrowLimit, totalFines);
    }
}
