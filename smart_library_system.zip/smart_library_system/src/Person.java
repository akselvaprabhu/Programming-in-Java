/**
 * Abstract base class representing a Person in the system.
 * Demonstrates Abstraction, Encapsulation, and Data Hiding.
 */
public abstract class Person {
    private String id;
    private String name;
    private String email;
    private String phone;

    /**
     * Default constructor.
     */
    public Person() {
        this.id = "";
        this.name = "";
        this.email = "";
        this.phone = "";
    }

    /**
     * Parameterized constructor.
     * @param id Unique identifier.
     * @param name Full name.
     * @param email Contact email address.
     * @param phone Contact phone number.
     */
    public Person(String id, String name, String email, String phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    // Abstract methods to be overridden by subclasses (Polymorphism & Abstraction)
    public abstract String getRole();
    public abstract void displayDetails();

    // Getters and Setters with Encapsulation
    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id != null && !id.trim().isEmpty()) {
            this.id = id.trim();
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name.trim();
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email != null && email.contains("@")) {
            this.email = email.trim();
        }
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        if (phone != null && !phone.trim().isEmpty()) {
            this.phone = phone.trim();
        }
    }

    @Override
    public String toString() {
        return String.format("ID: %-8s | Name: %-20s | Email: %-25s | Phone: %-12s", id, name, email, phone);
    }
}
