import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Abstract Notification class representing a message alert to library members.
 * Demonstrates Abstraction, Encapsulation, Polymorphism, and Method Overriding.
 */
public abstract class Notification {
    private static int idCounter = 5000;

    private final String notificationId;
    private final String recipientEmail;
    private final String recipientName;
    private final String bookTitle;
    private final LocalDateTime timestamp;

    /**
     * Parameterized constructor.
     * @param recipientEmail Recipient's email address.
     * @param recipientName Recipient's full name.
     * @param bookTitle Title of the relevant book.
     */
    public Notification(String recipientEmail, String recipientName, String bookTitle) {
        this.notificationId = "NOTIF-" + (++idCounter);
        this.recipientEmail = recipientEmail;
        this.recipientName = recipientName;
        this.bookTitle = bookTitle;
        this.timestamp = LocalDateTime.now();
    }

    /**
     * Abstract method to deliver the notification.
     * Implemented polymorphically by subclasses.
     */
    public abstract void send();

    /**
     * Returns the specific notification type.
     */
    public abstract String getNotificationType();

    public String getNotificationId() {
        return notificationId;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getFormattedTimestamp() {
        return timestamp.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    @Override
    public String toString() {
        return String.format("[%s] ID: %s | To: %s <%s> | Book: '%s' | Time: %s",
                getNotificationType(), notificationId, recipientName, recipientEmail, bookTitle, getFormattedTimestamp());
    }
}
