/**
 * Custom Exception thrown when book-related validation or operations fail.
 * Represents domain-specific error handling for the Library Management System.
 */
public class InvalidBookException extends Exception {

    /**
     * Constructs a new InvalidBookException with the specified detail message.
     * @param message Detailed reason for the exception.
     */
    public InvalidBookException(String message) {
        super(message);
    }

    /**
     * Constructs a new InvalidBookException with the specified message and cause.
     * @param message Detailed reason for the exception.
     * @param cause Underlying throwable cause.
     */
    public InvalidBookException(String message, Throwable cause) {
        super(message, cause);
    }
}
