/**
 * Multithreaded Notification worker.
 * Extends Thread to simulate asynchronous, concurrent notification delivery.
 * Demonstrates Multithreading, Thread Priorities, and Thread Synchronization.
 */
public class NotificationThread extends Thread {
    // Shared lock object for thread synchronization
    private static final Object CONSOLE_LOCK = new Object();

    private final Notification notification;
    private final int delayMillis;

    /**
     * Parameterized constructor.
     * @param threadName Name assigned to the thread.
     * @param notification The notification payload to send.
     * @param priority Thread priority (e.g., Thread.MAX_PRIORITY, Thread.NORM_PRIORITY).
     * @param delayMillis Simulated network/SMS latency in milliseconds.
     */
    public NotificationThread(String threadName, Notification notification, int priority, int delayMillis) {
        super(threadName);
        this.notification = notification;
        this.delayMillis = delayMillis;
        this.setPriority(priority);
    }

    @Override
    public void run() {
        try {
            // Simulate network latency
            if (delayMillis > 0) {
                Thread.sleep(delayMillis);
            }

            // Synchronize console output so concurrent thread messages do not interleave
            synchronized (CONSOLE_LOCK) {
                System.out.printf("[%s | Priority: %d] Processing notification:%n",
                        getName(), getPriority());
                notification.send();
            }
        } catch (InterruptedException e) {
            System.err.println("Thread " + getName() + " was interrupted: " + e.getMessage());
            Thread.currentThread().interrupt();
        }
    }
}
