import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * Core Library Management controller.
 * Coordinates Books, Members, Transactions, Reservations, and Multithreaded Notifications.
 * Integrated with DatabaseManager for automatic CSV file database persistence.
 */
public class Library {
    public static final double DAILY_FINE_RATE = 1.00; // .00 per day overdue
    public static final int DEFAULT_LOAN_DAYS = 14;

    // Collections Framework
    private final Map<String, Book> books;
    private final Map<String, Member> members;
    private final List<String> transactionLogs;

    public Library() {
        this.books = new HashMap<>();
        this.members = new HashMap<>();
        this.transactionLogs = new ArrayList<>();
    }

    public synchronized void clearAll() {
        books.clear();
        members.clear();
    }

    public synchronized void putBookDirectly(Book book) {
        if (book != null) {
            books.put(book.getBookId().toUpperCase(), book);
        }
    }

    public synchronized void putMemberDirectly(Member member) {
        if (member != null) {
            members.put(member.getId().toUpperCase(), member);
        }
    }

    // =========================================================================
    // BOOK MANAGEMENT
    // =========================================================================

    public synchronized void addBook(Book book) throws InvalidBookException {
        if (book == null) {
            throw new InvalidBookException("Cannot add a null book.");
        }
        if (books.containsKey(book.getBookId().toUpperCase())) {
            throw new InvalidBookException("Book with ID '" + book.getBookId() + "' already exists in catalog.");
        }
        books.put(book.getBookId().toUpperCase(), book);
        logTransaction("BOOK ADDED: " + book.getBookId() + " - " + book.getTitle());
        DatabaseManager.saveAll(this); // Persist to CSV
    }

    public synchronized void updateBook(String bookId, String title, String author, String category, int totalCopies)
            throws InvalidBookException {
        Book book = findBook(bookId);
        if (book == null) {
            throw new InvalidBookException("Book not found with ID: " + bookId);
        }
        book.setTitle(title);
        book.setAuthor(author);
        book.setCategory(category);
        book.setTotalCopies(totalCopies);
        logTransaction("BOOK UPDATED: " + book.getBookId());
        DatabaseManager.saveAll(this); // Persist to CSV
    }

    public synchronized void deleteBook(String bookId) throws InvalidBookException {
        Book book = findBook(bookId);
        if (book == null) {
            throw new InvalidBookException("Book not found with ID: " + bookId);
        }
        if (book.getTotalCopies() != book.getAvailableCopies()) {
            throw new InvalidBookException("Cannot delete book '" + bookId + "'. Copies are currently issued to members.");
        }
        if (book.getReservationCount() > 0) {
            throw new InvalidBookException("Cannot delete book '" + bookId + "'. There are active reservations.");
        }
        books.remove(book.getBookId().toUpperCase());
        logTransaction("BOOK DELETED: " + bookId);
        DatabaseManager.saveAll(this); // Persist to CSV
    }

    public List<Book> searchBooks(String query) {
        List<Book> results = new ArrayList<>();
        if (query == null || query.trim().isEmpty()) {
            return results;
        }
        String q = query.trim().toLowerCase();
        Iterator<Book> iterator = books.values().iterator();
        while (iterator.hasNext()) {
            Book b = iterator.next();
            if (b.getBookId().toLowerCase().contains(q) ||
                b.getTitle().toLowerCase().contains(q) ||
                b.getAuthor().toLowerCase().contains(q) ||
                b.getCategory().toLowerCase().contains(q)) {
                results.add(b);
            }
        }
        return results;
    }

    public void displayAvailableBooks() {
        System.out.println("\n----------------- AVAILABLE BOOKS IN LIBRARY -----------------");
        boolean found = false;
        for (Book b : books.values()) {
            if (b.getAvailableCopies() > 0) {
                System.out.println(b);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No books are currently available for borrowing.");
        }
        System.out.println("--------------------------------------------------------------\n");
    }

    public void displayAllBooks() {
        System.out.println("\n--------------------- ALL LIBRARY BOOKS ----------------------");
        if (books.isEmpty()) {
            System.out.println("No books found in the library catalog.");
        } else {
            List<Book> sorted = new ArrayList<>(books.values());
            Collections.sort(sorted);
            for (Book b : sorted) {
                System.out.println(b);
            }
        }
        System.out.println("--------------------------------------------------------------\n");
    }

    public Book findBook(String bookId) {
        if (bookId == null) return null;
        return books.get(bookId.trim().toUpperCase());
    }

    public Collection<Book> getAllBooks() {
        return Collections.unmodifiableCollection(books.values());
    }

    // =========================================================================
    // MEMBER MANAGEMENT
    // =========================================================================

    public synchronized void registerMember(Member member) throws InvalidMemberException {
        if (member == null) {
            throw new InvalidMemberException("Cannot register a null member.");
        }
        if (members.containsKey(member.getId().toUpperCase())) {
            throw new InvalidMemberException("Member with ID '" + member.getId() + "' already exists.");
        }
        members.put(member.getId().toUpperCase(), member);
        logTransaction("MEMBER REGISTERED: " + member.getId() + " - " + member.getName());
        DatabaseManager.saveAll(this); // Persist to CSV
    }

    public synchronized void updateMember(String memberId, String name, String email, String phone, int maxLimit)
            throws InvalidMemberException {
        Member member = findMember(memberId);
        if (member == null) {
            throw new InvalidMemberException("Member not found with ID: " + memberId);
        }
        member.setName(name);
        member.setEmail(email);
        member.setPhone(phone);
        member.setMaxBorrowLimit(maxLimit);
        logTransaction("MEMBER UPDATED: " + memberId);
        DatabaseManager.saveAll(this); // Persist to CSV
    }

    public List<Member> searchMembers(String query) {
        List<Member> results = new ArrayList<>();
        if (query == null || query.trim().isEmpty()) {
            return results;
        }
        String q = query.trim().toLowerCase();
        for (Member m : members.values()) {
            if (m.getId().toLowerCase().contains(q) ||
                m.getName().toLowerCase().contains(q) ||
                m.getEmail().toLowerCase().contains(q)) {
                results.add(m);
            }
        }
        return results;
    }

    public void displayAllMembers() {
        System.out.println("\n--------------------- REGISTERED MEMBERS ---------------------");
        if (members.isEmpty()) {
            System.out.println("No members currently registered.");
        } else {
            for (Member m : members.values()) {
                System.out.println(m);
            }
        }
        System.out.println("--------------------------------------------------------------\n");
    }

    public Member findMember(String memberId) {
        if (memberId == null) return null;
        return members.get(memberId.trim().toUpperCase());
    }

    public Collection<Member> getAllMembers() {
        return Collections.unmodifiableCollection(members.values());
    }

    // =========================================================================
    // BOOK TRANSACTIONS (ISSUE & RETURN) - THREAD-SAFE
    // =========================================================================

    public synchronized boolean issueBook(String bookId, String memberId, int loanDays)
            throws InvalidBookException, InvalidMemberException {
        Book book = findBook(bookId);
        if (book == null) {
            throw new InvalidBookException("Book not found with ID: " + bookId);
        }

        Member member = findMember(memberId);
        if (member == null) {
            throw new InvalidMemberException("Member not found with ID: " + memberId);
        }

        if (member.getBorrowedBookIds().contains(book.getBookId())) {
            throw new InvalidBookException("Member '" + memberId + "' has already borrowed a copy of this book.");
        }

        if (!member.canBorrow()) {
            throw new InvalidMemberException("Borrowing limit reached! Member has already borrowed "
                    + member.getMaxBorrowLimit() + " books.");
        }

        if (member.getTotalFines() > 20.00) {
            throw new InvalidMemberException("Member has unpaid fines of $" + String.format("%.2f", member.getTotalFines())
                    + ". Clear fines before borrowing new books.");
        }

        Queue<Reservation> queue = book.getReservationQueue();
        if (!queue.isEmpty() && !queue.peek().getMemberId().equalsIgnoreCase(memberId)) {
            if (book.getAvailableCopies() <= 1) {
                throw new InvalidBookException("Book is currently on hold for reserved member '"
                        + queue.peek().getMemberId() + "'. Place a reservation instead.");
            }
        }

        if (!book.isAvailable()) {
            throw new InvalidBookException("No copies available for book '" + book.getTitle() + "'. You may reserve it.");
        }

        int days = (loanDays > 0) ? loanDays : DEFAULT_LOAN_DAYS;
        LocalDate issueDate = LocalDate.now();
        LocalDate dueDate = issueDate.plusDays(days);

        boolean borrowed = book.borrowCopy(member.getId(), dueDate);
        if (borrowed) {
            member.borrowBook(book.getBookId(), issueDate);
            if (!queue.isEmpty() && queue.peek().getMemberId().equalsIgnoreCase(memberId)) {
                Reservation res = book.pollNextReservation();
                res.setStatus(Reservation.Status.FULFILLED);
            }
            logTransaction(String.format("BOOK ISSUED: '%s' to Member '%s' (Due: %s)", book.getTitle(), member.getName(), dueDate));
            DatabaseManager.saveAll(this); // Persist to CSV
            return true;
        }
        return false;
    }

    public synchronized double returnBook(String bookId, String memberId)
            throws InvalidBookException, InvalidMemberException {
        Book book = findBook(bookId);
        if (book == null) {
            throw new InvalidBookException("Book not found with ID: " + bookId);
        }

        Member member = findMember(memberId);
        if (member == null) {
            throw new InvalidMemberException("Member not found with ID: " + memberId);
        }

        LocalDate dueDate = book.returnCopy(member.getId());
        if (dueDate == null) {
            throw new InvalidBookException("Member '" + memberId + "' does not currently have book '" + bookId + "' on loan.");
        }

        member.returnBook(book.getBookId());

        LocalDate returnDate = LocalDate.now();
        double fine = 0.0;
        if (returnDate.isAfter(dueDate)) {
            long overdueDays = ChronoUnit.DAYS.between(dueDate, returnDate);
            fine = overdueDays * DAILY_FINE_RATE;
            member.addFine(fine);
            logTransaction(String.format("OVERDUE RETURN: '%s' by '%s' (%d days overdue, Fine: $%.2f)",
                    book.getBookId(), member.getId(), overdueDays, fine));
        } else {
            logTransaction(String.format("BOOK RETURNED: '%s' by '%s' (On time)", book.getBookId(), member.getId()));
        }

        Reservation nextRes = book.pollNextReservation();
        if (nextRes != null) {
            Member nextMember = findMember(nextRes.getMemberId());
            String nextName = (nextMember != null) ? nextMember.getName() : nextRes.getMemberId();
            System.out.printf("[AUTO-NOTIFICATION] Hold notification sent to next queued member: %s (%s) for Book '%s'%n",
                    nextName, nextRes.getMemberId(), book.getTitle());
        }

        DatabaseManager.saveAll(this); // Persist to CSV
        return fine;
    }

    // =========================================================================
    // RESERVATION SYSTEM
    // =========================================================================

    public synchronized Reservation reserveBook(String bookId, String memberId)
            throws InvalidBookException, InvalidMemberException {
        Book book = findBook(bookId);
        if (book == null) {
            throw new InvalidBookException("Book not found with ID: " + bookId);
        }

        Member member = findMember(memberId);
        if (member == null) {
            throw new InvalidMemberException("Member not found with ID: " + memberId);
        }

        if (member.getBorrowedBookIds().contains(book.getBookId())) {
            throw new InvalidBookException("Member already has this book borrowed. Cannot place reservation.");
        }

        Reservation reservation = new Reservation(book.getBookId(), member.getId());
        boolean queued = book.addReservation(reservation);
        if (!queued) {
            throw new InvalidBookException("Member '" + memberId + "' already has an active reservation for this book.");
        }

        logTransaction(String.format("RESERVATION PLACED: Res ID %s for Book '%s' by Member '%s' (Queue pos: %d)",
                reservation.getReservationId(), book.getBookId(), member.getId(), book.getReservationCount()));
        DatabaseManager.saveAll(this); // Persist to CSV
        return reservation;
    }

    public synchronized boolean cancelReservation(String bookId, String memberId)
            throws InvalidBookException, InvalidMemberException {
        Book book = findBook(bookId);
        if (book == null) {
            throw new InvalidBookException("Book not found with ID: " + bookId);
        }

        Member member = findMember(memberId);
        if (member == null) {
            throw new InvalidMemberException("Member not found with ID: " + memberId);
        }

        boolean cancelled = book.cancelReservation(member.getId());
        if (!cancelled) {
            throw new InvalidBookException("No pending reservation found for member '" + memberId + "' on book '" + bookId + "'.");
        }

        logTransaction("RESERVATION CANCELLED: Book " + bookId + " for Member " + memberId);
        DatabaseManager.saveAll(this); // Persist to CSV
        return true;
    }

    // =========================================================================
    // NOTIFICATION ENGINE (MULTITHREADED)
    // =========================================================================

    public void sendNotificationsMultithreaded() {
        System.out.println("\n================================================================");
        System.out.println("       LAUNCHING CONCURRENT MULTITHREADED NOTIFICATION SYSTEM   ");
        System.out.println("================================================================");

        List<Notification> notificationBatch = new ArrayList<>();
        LocalDate today = LocalDate.now();

        for (Book book : books.values()) {
            for (Map.Entry<String, LocalDate> loan : book.getActiveLoans().entrySet()) {
                String memberId = loan.getKey();
                LocalDate dueDate = loan.getValue();
                Member member = findMember(memberId);

                if (member == null) continue;

                if (today.isAfter(dueDate)) {
                    long overdueDays = ChronoUnit.DAYS.between(dueDate, today);
                    double fine = overdueDays * DAILY_FINE_RATE;
                    notificationBatch.add(new OverdueNotification(
                            member.getEmail(), member.getName(), book.getTitle(), overdueDays, fine));
                } else {
                    notificationBatch.add(new DueDateNotification(
                            member.getEmail(), member.getName(), book.getTitle(), dueDate));
                }
            }
        }

        if (notificationBatch.isEmpty()) {
            System.out.println("No active loans requiring notifications at this time.");
            System.out.println("================================================================\n");
            return;
        }

        List<NotificationThread> threads = new ArrayList<>();
        int threadIndex = 1;

        for (Notification notif : notificationBatch) {
            int priority = (notif instanceof OverdueNotification) ? Thread.MAX_PRIORITY : Thread.NORM_PRIORITY;
            int simulatedDelay = (notif instanceof OverdueNotification) ? 100 : 250;

            NotificationThread thread = new NotificationThread(
                    "WorkerThread-" + threadIndex++,
                    notif,
                    priority,
                    simulatedDelay
            );
            threads.add(thread);
        }

        System.out.printf("Starting %d concurrent notification worker threads...%n%n", threads.size());

        for (NotificationThread t : threads) {
            t.start();
        }

        for (NotificationThread t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                System.err.println("Notification thread waiting interrupted: " + e.getMessage());
                Thread.currentThread().interrupt();
            }
        }

        System.out.println("================================================================");
        System.out.printf("All %d notification thread workers finished successfully.%n", threads.size());
        System.out.println("================================================================\n");
    }

    // =========================================================================
    // DATABASE INITIALIZATION & SAMPLE SEEDING
    // =========================================================================

    public void seedSampleData() {
        // Loads data from CSV flat-file database (creates initial CSV files if empty)
        DatabaseManager.loadAll(this);
    }

    private void logTransaction(String log) {
        transactionLogs.add("[" + LocalDate.now() + "] " + log);
    }

    public List<String> getTransactionLogs() {
        return Collections.unmodifiableList(transactionLogs);
    }
}