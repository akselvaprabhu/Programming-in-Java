import java.util.List;
import java.util.Scanner;

/**
 * Main application entry point for the Smart Library Management System.
 * Supports both Console Menu Interface and Desktop GUI Applet Window.
 */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final Library library = new Library();

    public static void main(String[] args) {
        // If --gui flag is passed, launch Graphical Interface directly
        if (args.length > 0 && (args[0].equalsIgnoreCase("--gui") || args[0].equalsIgnoreCase("-g") || args[0].equalsIgnoreCase("gui"))) {
            LibraryGUI.main(args);
            return;
        }

        // Automatically seed sample data for immediate testing and verification
        library.seedSampleData();

        System.out.println("=================================================================");
        System.out.println("  WELCOME TO SMART LIBRARY MANAGEMENT & NOTIFICATION SYSTEM      ");
        System.out.println("  Java JDK 17 Edition | OOP, Collections & Multithreading Demo   ");
        System.out.println("=================================================================");
        System.out.println("[INFO] Sample books, members, active loans, and waitlists loaded.");
        System.out.println("[TIP]  Type '0' at any time to open the Modern Desktop GUI Window!");

        boolean running = true;
        while (running) {
            displayMenu();
            System.out.print("Enter your choice (0-12): ");
            String input = scanner.nextLine().trim();

            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("\n[ERROR] Invalid choice. Please enter a numerical option from 0 to 12.\n");
                continue;
            }

            try {
                switch (choice) {
                    case 0 -> {
                        System.out.println("\n[LAUNCHING] Starting Desktop GUI Applet Window...");
                        LibraryGUI.main(new String[]{});
                    }
                    case 1 -> handleAddBook();
                    case 2 -> handleRegisterMember();
                    case 3 -> handleSearchBook();
                    case 4 -> handleIssueBook();
                    case 5 -> handleReturnBook();
                    case 6 -> handleReserveBook();
                    case 7 -> handleCancelReservation();
                    case 8 -> handleDisplayBooks();
                    case 9 -> handleDisplayMembers();
                    case 10 -> handleGenerateReports();
                    case 11 -> handleSendNotifications();
                    case 12 -> {
                        System.out.println("\n=================================================================");
                        System.out.println("  Thank you for using Smart Library Management System. Goodbye!  ");
                        System.out.println("=================================================================\n");
                        running = false;
                    }
                    default -> System.out.println("\n[ERROR] Invalid option selected. Please choose between 0 and 12.\n");
                }
            } catch (Exception e) {
                System.out.println("\n[SYSTEM ERROR] An unexpected error occurred: " + e.getMessage());
            } finally {
                if (running) {
                    System.out.println();
                }
            }
        }

        scanner.close();
    }

    /**
     * Displays the primary menu interface.
     */
    private static void displayMenu() {
        System.out.println("====================================");
        System.out.println("  SMART LIBRARY MANAGEMENT SYSTEM   ");
        System.out.println("====================================");
        System.out.println(" 0. Launch Desktop GUI Window (Applet)");
        System.out.println(" 1. Add Book");
        System.out.println(" 2. Register Member");
        System.out.println(" 3. Search Book");
        System.out.println(" 4. Issue Book");
        System.out.println(" 5. Return Book");
        System.out.println(" 6. Reserve Book");
        System.out.println(" 7. Cancel Reservation");
        System.out.println(" 8. Display Books");
        System.out.println(" 9. Display Members");
        System.out.println("10. Generate Reports");
        System.out.println("11. Send Notifications");
        System.out.println("12. Exit");
        System.out.println("====================================");
    }

    private static void handleAddBook() {
        System.out.println("\n--- [1] ADD NEW BOOK ---");
        try {
            System.out.print("Enter Book ID (e.g., B107): ");
            String id = scanner.nextLine().trim();

            System.out.print("Enter Title: ");
            String title = scanner.nextLine().trim();

            System.out.print("Enter Author: ");
            String author = scanner.nextLine().trim();

            System.out.print("Enter Category/Genre: ");
            String category = scanner.nextLine().trim();

            System.out.print("Enter Total Copies: ");
            int copies = Integer.parseInt(scanner.nextLine().trim());

            Book book = new Book(id, title, author, category, copies);
            library.addBook(book);
            System.out.println("[SUCCESS] Book '" + title + "' (ID: " + id + ") added to catalog successfully!");
        } catch (NumberFormatException e) {
            System.out.println("[ERROR] Total copies must be a valid positive integer.");
        } catch (InvalidBookException e) {
            System.out.println("[ERROR] Failed to add book: " + e.getMessage());
        }
    }

    private static void handleRegisterMember() {
        System.out.println("\n--- [2] REGISTER NEW MEMBER ---");
        try {
            System.out.print("Enter Member ID (e.g., M005): ");
            String id = scanner.nextLine().trim();

            System.out.print("Enter Full Name: ");
            String name = scanner.nextLine().trim();

            System.out.print("Enter Email Address: ");
            String email = scanner.nextLine().trim();

            System.out.print("Enter Phone Number: ");
            String phone = scanner.nextLine().trim();

            System.out.print("Enter Max Borrow Limit (default 3, press Enter to use default): ");
            String limitInput = scanner.nextLine().trim();
            int limit = limitInput.isEmpty() ? Member.DEFAULT_BORROW_LIMIT : Integer.parseInt(limitInput);

            Member member = new Member(id, name, email, phone, limit);
            library.registerMember(member);
            System.out.println("[SUCCESS] Member '" + name + "' (ID: " + id + ") registered successfully!");
        } catch (NumberFormatException e) {
            System.out.println("[ERROR] Borrow limit must be a valid integer.");
        } catch (InvalidMemberException e) {
            System.out.println("[ERROR] Failed to register member: " + e.getMessage());
        }
    }

    private static void handleSearchBook() {
        System.out.println("\n--- [3] SEARCH BOOK ---");
        System.out.print("Enter Search Term (ID, Title, Author, or Category): ");
        String query = scanner.nextLine().trim();

        List<Book> results = library.searchBooks(query);
        if (results.isEmpty()) {
            System.out.println("[INFO] No books found matching '" + query + "'.");
        } else {
            System.out.printf("%nFound %d matching book(s):%n", results.size());
            for (Book b : results) {
                System.out.println(" -> " + b);
            }
        }
    }

    private static void handleIssueBook() {
        System.out.println("\n--- [4] ISSUE BOOK ---");
        try {
            System.out.print("Enter Book ID to Issue: ");
            String bookId = scanner.nextLine().trim();

            System.out.print("Enter Member ID: ");
            String memberId = scanner.nextLine().trim();

            System.out.print("Enter Loan Period in Days (default 14, press Enter for default): ");
            String daysInput = scanner.nextLine().trim();
            int days = daysInput.isEmpty() ? Library.DEFAULT_LOAN_DAYS : Integer.parseInt(daysInput);

            boolean success = library.issueBook(bookId, memberId, days);
            if (success) {
                System.out.println("[SUCCESS] Book '" + bookId + "' successfully issued to member '" + memberId + "' for " + days + " days.");
            }
        } catch (NumberFormatException e) {
            System.out.println("[ERROR] Loan period must be a valid positive integer.");
        } catch (InvalidBookException | InvalidMemberException e) {
            System.out.println("[TRANSACTION FAILED] " + e.getMessage());
        }
    }

    private static void handleReturnBook() {
        System.out.println("\n--- [5] RETURN BOOK ---");
        try {
            System.out.print("Enter Book ID to Return: ");
            String bookId = scanner.nextLine().trim();

            System.out.print("Enter Member ID: ");
            String memberId = scanner.nextLine().trim();

            double fine = library.returnBook(bookId, memberId);
            System.out.println("[SUCCESS] Book '" + bookId + "' returned successfully by member '" + memberId + "'.");
            if (fine > 0) {
                System.out.printf("[NOTICE] An overdue fine of $%.2f was charged to the member's account.%n", fine);
            } else {
                System.out.println("[NOTICE] Returned on time. No overdue fines incurred.");
            }
        } catch (InvalidBookException | InvalidMemberException e) {
            System.out.println("[TRANSACTION FAILED] " + e.getMessage());
        }
    }

    private static void handleReserveBook() {
        System.out.println("\n--- [6] RESERVE BOOK ---");
        try {
            System.out.print("Enter Book ID to Reserve: ");
            String bookId = scanner.nextLine().trim();

            System.out.print("Enter Member ID: ");
            String memberId = scanner.nextLine().trim();

            Reservation res = library.reserveBook(bookId, memberId);
            Book book = library.findBook(bookId);
            int queuePos = (book != null) ? book.getReservationCount() : 1;
            System.out.println("[SUCCESS] Reservation created successfully!");
            System.out.println("  Reservation ID: " + res.getReservationId());
            System.out.println("  Position in Waitlist Queue: #" + queuePos);
        } catch (InvalidBookException | InvalidMemberException e) {
            System.out.println("[RESERVATION FAILED] " + e.getMessage());
        }
    }

    private static void handleCancelReservation() {
        System.out.println("\n--- [7] CANCEL RESERVATION ---");
        try {
            System.out.print("Enter Book ID: ");
            String bookId = scanner.nextLine().trim();

            System.out.print("Enter Member ID: ");
            String memberId = scanner.nextLine().trim();

            boolean cancelled = library.cancelReservation(bookId, memberId);
            if (cancelled) {
                System.out.println("[SUCCESS] Reservation cancelled successfully for member '" + memberId + "' on book '" + bookId + "'.");
            }
        } catch (InvalidBookException | InvalidMemberException e) {
            System.out.println("[CANCELLATION FAILED] " + e.getMessage());
        }
    }

    private static void handleDisplayBooks() {
        System.out.println("\n--- [8] DISPLAY BOOKS ---");
        System.out.println("1. Display All Books");
        System.out.println("2. Display Available Books Only");
        System.out.print("Choose display mode (1 or 2): ");
        String choice = scanner.nextLine().trim();

        if ("2".equals(choice)) {
            library.displayAvailableBooks();
        } else {
            library.displayAllBooks();
        }
    }

    private static void handleDisplayMembers() {
        System.out.println("\n--- [9] DISPLAY MEMBERS ---");
        library.displayAllMembers();
    }

    private static void handleGenerateReports() {
        System.out.println("\n--- [10] GENERATE REPORTS ---");
        System.out.println("1. Circulation Report (Active Loans & Due Dates)");
        System.out.println("2. Inventory Report (Catalog & Stock Breakdown)");
        System.out.println("3. Fine Report (Outstanding Dues by Member)");
        System.out.println("4. Reserved Books Report (Waitlists & Queue Positions)");
        System.out.println("5. Generate All Reports");
        System.out.print("Select report type (1-5): ");
        String reportChoice = scanner.nextLine().trim();

        switch (reportChoice) {
            case "1" -> Report.generateCirculationReport(library);
            case "2" -> Report.generateInventoryReport(library);
            case "3" -> Report.generateFineReport(library);
            case "4" -> Report.generateReservedBooksReport(library);
            case "5" -> {
                Report.generateCirculationReport(library);
                Report.generateInventoryReport(library);
                Report.generateFineReport(library);
                Report.generateReservedBooksReport(library);
            }
            default -> System.out.println("[ERROR] Invalid report option.");
        }
    }

    private static void handleSendNotifications() {
        System.out.println("\n--- [11] SEND NOTIFICATIONS ---");
        library.sendNotificationsMultithreaded();
    }
}