import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Reservation entity representing a hold/reservation placed on a book.
 * Demonstrates Encapsulation and is used within Queue collections for waitlists.
 */
public class Reservation {
    public enum Status {
        PENDING,
        FULFILLED,
        CANCELLED
    }

    private static int counter = 1000;

    private final String reservationId;
    private final String bookId;
    private final String memberId;
    private final LocalDateTime reservationDate;
    private Status status;

    /**
     * Parameterized constructor generating automatic reservation ID.
     * @param bookId Book identifier.
     * @param memberId Member identifier.
     */
    public Reservation(String bookId, String memberId) {
        this.reservationId = "RES-" + (++counter);
        this.bookId = bookId;
        this.memberId = memberId;
        this.reservationDate = LocalDateTime.now();
        this.status = Status.PENDING;
    }

    /**
     * Overloaded constructor with explicit reservation ID and timestamp.
     */
    public Reservation(String reservationId, String bookId, String memberId, LocalDateTime reservationDate, Status status) {
        this.reservationId = reservationId;
        this.bookId = bookId;
        this.memberId = memberId;
        this.reservationDate = reservationDate;
        this.status = status;
    }

    public String getReservationId() {
        return reservationId;
    }

    public String getBookId() {
        return bookId;
    }

    public String getMemberId() {
        return memberId;
    }

    public LocalDateTime getReservationDate() {
        return reservationDate;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return String.format("Res ID: %-10s | Book: %-8s | Member: %-8s | Date: %s | Status: %s",
                reservationId, bookId, memberId, reservationDate.format(dtf), status);
    }
}
