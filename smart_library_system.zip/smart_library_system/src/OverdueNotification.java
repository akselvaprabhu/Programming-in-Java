/**
 * Concrete Notification subclass for Overdue Books.
 * Demonstrates Inheritance, Polymorphism, and Method Overriding.
 */
public class OverdueNotification extends Notification {
    private final long daysOverdue;
    private final double fineAmount;

    public OverdueNotification(String recipientEmail, String recipientName, String bookTitle, long daysOverdue, double fineAmount) {
        super(recipientEmail, recipientName, bookTitle);
        this.daysOverdue = daysOverdue;
        this.fineAmount = fineAmount;
    }

    public long getDaysOverdue() {
        return daysOverdue;
    }

    public double getFineAmount() {
        return fineAmount;
    }

    @Override
    public String getNotificationType() {
        return "OVERDUE ALERT";
    }

    @Override
    public void send() {
        System.out.println("  [EMAIL DISPATCHED] -> " + getRecipientEmail());
        System.out.printf("  Dear %s,%n", getRecipientName());
        System.out.printf("  URGENT: Your borrowed book '%s' is overdue by %d day(s).%n", getBookTitle(), daysOverdue);
        System.out.printf("  Accrued Fine: $%.2f. Please return the book immediately to avoid additional penalties.%n", fineAmount);
        System.out.println("  " + "-".repeat(50));
    }

    @Override
    public String toString() {
        return String.format("%s | Days Overdue: %d | Fine: $%.2f", super.toString(), daysOverdue, fineAmount);
    }
}
