import java.time.LocalDate;

/**
 * Concrete Notification subclass for upcoming Due Date Reminders.
 * Demonstrates Inheritance, Polymorphism, and Method Overriding.
 */
public class DueDateNotification extends Notification {
    private final LocalDate dueDate;

    public DueDateNotification(String recipientEmail, String recipientName, String bookTitle, LocalDate dueDate) {
        super(recipientEmail, recipientName, bookTitle);
        this.dueDate = dueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    @Override
    public String getNotificationType() {
        return "DUE DATE REMINDER";
    }

    @Override
    public void send() {
        System.out.println("  [EMAIL DISPATCHED] -> " + getRecipientEmail());
        System.out.printf("  Dear %s,%n", getRecipientName());
        System.out.printf("  REMINDER: Your borrowed book '%s' is due on %s.%n", getBookTitle(), dueDate);
        System.out.println("  Please return or renew on time to avoid overdue charges ($1.00/day).");
        System.out.println("  " + "-".repeat(50));
    }

    @Override
    public String toString() {
        return String.format("%s | Due Date: %s", super.toString(), dueDate);
    }
}
