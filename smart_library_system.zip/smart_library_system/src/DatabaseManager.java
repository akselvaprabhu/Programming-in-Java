import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Map;
import java.util.Queue;

/**
 * CSV File-Based Database Persistence Manager.
 * Provides flat-file database storage for Books, Members, Active Loans, and Reservations.
 * Ensures data durability across application sessions using standard Java I/O.
 */
public class DatabaseManager {

    private static final String DATA_DIR = "data";
    private static final String BOOKS_FILE = DATA_DIR + File.separator + "books.csv";
    private static final String MEMBERS_FILE = DATA_DIR + File.separator + "members.csv";
    private static final String LOANS_FILE = DATA_DIR + File.separator + "loans.csv";
    private static final String RESERVATIONS_FILE = DATA_DIR + File.separator + "reservations.csv";

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    /**
     * Ensures data directory and initial CSV files exist.
     * If files are missing, populates them with default seed data.
     */
    public static void initializeDatabase() {
        File dir = new File(DATA_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        File booksFile = new File(BOOKS_FILE);
        File membersFile = new File(MEMBERS_FILE);
        File loansFile = new File(LOANS_FILE);
        File resFile = new File(RESERVATIONS_FILE);

        if (!booksFile.exists() || booksFile.length() == 0) {
            seedDefaultBooks();
        }
        if (!membersFile.exists() || membersFile.length() == 0) {
            seedDefaultMembers();
        }
        if (!loansFile.exists() || loansFile.length() == 0) {
            seedDefaultLoans();
        }
        if (!resFile.exists() || resFile.length() == 0) {
            seedDefaultReservations();
        }
    }

    // =========================================================================
    // LOAD OPERATIONS
    // =========================================================================

    /**
     * Loads all data from CSV files into memory.
     */
    public static synchronized void loadAll(Library library) {
        initializeDatabase();
        library.clearAll();

        loadBooks(library);
        loadMembers(library);
        loadLoans(library);
        loadReservations(library);
    }

    private static void loadBooks(Library library) {
        File file = new File(BOOKS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine(); // Skip header
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = parseCsvLine(line);
                if (parts.length >= 6) {
                    String id = parts[0].trim();
                    String title = parts[1].trim();
                    String author = parts[2].trim();
                    String category = parts[3].trim();
                    int total = Integer.parseInt(parts[4].trim());
                    int avail = Integer.parseInt(parts[5].trim());

                    Book book = new Book(id, title, author, category, total);
                    library.putBookDirectly(book);
                }
            }
        } catch (Exception e) {
            System.err.println("[CSV DB] Error reading books.csv: " + e.getMessage());
        }
    }

    private static void loadMembers(Library library) {
        File file = new File(MEMBERS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine(); // Skip header
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = parseCsvLine(line);
                if (parts.length >= 6) {
                    String id = parts[0].trim();
                    String name = parts[1].trim();
                    String email = parts[2].trim();
                    String phone = parts[3].trim();
                    int limit = Integer.parseInt(parts[4].trim());
                    double fines = Double.parseDouble(parts[5].trim());

                    Member member = new Member(id, name, email, phone, limit);
                    member.addFine(fines);
                    library.putMemberDirectly(member);
                }
            }
        } catch (Exception e) {
            System.err.println("[CSV DB] Error reading members.csv: " + e.getMessage());
        }
    }

    private static void loadLoans(Library library) {
        File file = new File(LOANS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine(); // Skip header
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = parseCsvLine(line);
                if (parts.length >= 4) {
                    String bookId = parts[0].trim();
                    String memberId = parts[1].trim();
                    LocalDate issueDate = LocalDate.parse(parts[2].trim(), DATE_FORMATTER);
                    LocalDate dueDate = LocalDate.parse(parts[3].trim(), DATE_FORMATTER);

                    Book book = library.findBook(bookId);
                    Member member = library.findMember(memberId);
                    if (book != null && member != null) {
                        book.borrowCopy(memberId, dueDate);
                        member.borrowBook(bookId, issueDate);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[CSV DB] Error reading loans.csv: " + e.getMessage());
        }
    }

    private static void loadReservations(Library library) {
        File file = new File(RESERVATIONS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine(); // Skip header
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = parseCsvLine(line);
                if (parts.length >= 5) {
                    String resId = parts[0].trim();
                    String bookId = parts[1].trim();
                    String memberId = parts[2].trim();
                    LocalDateTime resDate = LocalDateTime.parse(parts[3].trim(), DATE_TIME_FORMATTER);
                    Reservation.Status status = Reservation.Status.valueOf(parts[4].trim());

                    if (status == Reservation.Status.PENDING) {
                        Reservation res = new Reservation(resId, bookId, memberId, resDate, status);
                        Book book = library.findBook(bookId);
                        if (book != null) {
                            book.addReservation(res);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[CSV DB] Error reading reservations.csv: " + e.getMessage());
        }
    }

    // =========================================================================
    // SAVE OPERATIONS
    // =========================================================================

    /**
     * Persists all in-memory collections into CSV files.
     */
    public static synchronized void saveAll(Library library) {
        saveBooks(library.getAllBooks());
        saveMembers(library.getAllMembers());
        saveLoans(library.getAllBooks());
        saveReservations(library.getAllBooks());
    }

    private static void saveBooks(Collection<Book> books) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(BOOKS_FILE))) {
            writer.write("bookId,title,author,category,totalCopies,availableCopies\n");
            for (Book b : books) {
                writer.write(String.format("%s,%s,%s,%s,%d,%d\n",
                        escapeCsv(b.getBookId()),
                        escapeCsv(b.getTitle()),
                        escapeCsv(b.getAuthor()),
                        escapeCsv(b.getCategory()),
                        b.getTotalCopies(),
                        b.getAvailableCopies()));
            }
        } catch (IOException e) {
            System.err.println("[CSV DB] Failed to save books.csv: " + e.getMessage());
        }
    }

    private static void saveMembers(Collection<Member> members) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(MEMBERS_FILE))) {
            writer.write("memberId,name,email,phone,maxBorrowLimit,totalFines\n");
            for (Member m : members) {
                writer.write(String.format("%s,%s,%s,%s,%d,%.2f\n",
                        escapeCsv(m.getId()),
                        escapeCsv(m.getName()),
                        escapeCsv(m.getEmail()),
                        escapeCsv(m.getPhone()),
                        m.getMaxBorrowLimit(),
                        m.getTotalFines()));
            }
        } catch (IOException e) {
            System.err.println("[CSV DB] Failed to save members.csv: " + e.getMessage());
        }
    }

    private static void saveLoans(Collection<Book> books) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOANS_FILE))) {
            writer.write("bookId,memberId,issueDate,dueDate\n");
            for (Book b : books) {
                for (Map.Entry<String, LocalDate> loan : b.getActiveLoans().entrySet()) {
                    String memberId = loan.getKey();
                    LocalDate dueDate = loan.getValue();
                    LocalDate issueDate = dueDate.minusDays(14); // approximate or default
                    writer.write(String.format("%s,%s,%s,%s\n",
                            escapeCsv(b.getBookId()),
                            escapeCsv(memberId),
                            issueDate.format(DATE_FORMATTER),
                            dueDate.format(DATE_FORMATTER)));
                }
            }
        } catch (IOException e) {
            System.err.println("[CSV DB] Failed to save loans.csv: " + e.getMessage());
        }
    }

    private static void saveReservations(Collection<Book> books) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RESERVATIONS_FILE))) {
            writer.write("reservationId,bookId,memberId,reservationDate,status\n");
            for (Book b : books) {
                Queue<Reservation> q = b.getReservationQueue();
                for (Reservation r : q) {
                    writer.write(String.format("%s,%s,%s,%s,%s\n",
                            escapeCsv(r.getReservationId()),
                            escapeCsv(r.getBookId()),
                            escapeCsv(r.getMemberId()),
                            r.getReservationDate().format(DATE_TIME_FORMATTER),
                            r.getStatus().name()));
                }
            }
        } catch (IOException e) {
            System.err.println("[CSV DB] Failed to save reservations.csv: " + e.getMessage());
        }
    }

    // =========================================================================
    // SEED INITIAL CSV DATA
    // =========================================================================

    private static void seedDefaultBooks() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(BOOKS_FILE))) {
            writer.write("bookId,title,author,category,totalCopies,availableCopies\n");
            writer.write("B101,Effective Java,Joshua Bloch,Computer Science,3,3\n");
            writer.write("B102,Clean Code,Robert C. Martin,Computer Science,2,1\n");
            writer.write("B103,Design Patterns,Erich Gamma et al.,Software Eng,2,2\n");
            writer.write("B104,The Pragmatic Programmer,Andy Hunt,Software Eng,1,0\n");
            writer.write("B105,Artificial Intelligence,Stuart Russell,AI & Robotics,2,1\n");
            writer.write("B106,Introduction to Algorithms,Thomas H. Cormen,Algorithms,1,1\n");
        } catch (IOException ignored) {}
    }

    private static void seedDefaultMembers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(MEMBERS_FILE))) {
            writer.write("memberId,name,email,phone,maxBorrowLimit,totalFines\n");
            writer.write("M001,Alice Johnson,alice.j@university.edu,555-0101,3,0.00\n");
            writer.write("M002,Bob Smith,bob.smith@university.edu,555-0102,3,0.00\n");
            writer.write("M003,Charlie Brown,charlie.b@university.edu,555-0103,2,0.00\n");
            writer.write("M004,Diana Prince,diana.p@university.edu,555-0104,4,0.00\n");
        } catch (IOException ignored) {}
    }

    private static void seedDefaultLoans() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOANS_FILE))) {
            LocalDate today = LocalDate.now();
            writer.write("bookId,memberId,issueDate,dueDate\n");
            writer.write(String.format("B102,M002,%s,%s\n", today.minusDays(7), today.plusDays(7)));
            writer.write(String.format("B104,M003,%s,%s\n", today.minusDays(2), today.plusDays(12)));
            writer.write(String.format("B105,M001,%s,%s\n", today.minusDays(19), today.minusDays(5))); // Overdue loan
        } catch (IOException ignored) {}
    }

    private static void seedDefaultReservations() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RESERVATIONS_FILE))) {
            LocalDateTime now = LocalDateTime.now();
            writer.write("reservationId,bookId,memberId,reservationDate,status\n");
            writer.write(String.format("RES-1001,B104,M001,%s,PENDING\n", now.minusHours(5).format(DATE_TIME_FORMATTER)));
            writer.write(String.format("RES-1002,B104,M002,%s,PENDING\n", now.minusHours(2).format(DATE_TIME_FORMATTER)));
            writer.write(String.format("RES-1003,B102,M004,%s,PENDING\n", now.minusHours(1).format(DATE_TIME_FORMATTER)));
        } catch (IOException ignored) {}
    }

    // =========================================================================
    // CSV HELPER METHODS
    // =========================================================================

    private static String escapeCsv(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    private static String[] parseCsvLine(String line) {
        java.util.List<String> tokens = new java.util.ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '\"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '\"') {
                    sb.append('\"');
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                tokens.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        tokens.add(sb.toString());
        return tokens.toArray(new String[0]);
    }
}