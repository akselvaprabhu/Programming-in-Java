import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

/**
 * Book entity representing an item in the library catalog.
 * Demonstrates Encapsulation, Data Hiding, Thread Synchronization,
 * Generics, and Collections (Queue/LinkedList, HashMap, Iterator).
 */
public class Book implements Comparable<Book> {
    private String bookId;
    private String title;
    private String author;
    private String category;
    private int totalCopies;
    private int availableCopies;

    // Queue of reservations demonstrating Queue/LinkedList for FIFO waitlist
    private final Queue<Reservation> reservationQueue;
    // Map tracking active loans (MemberId -> DueDate)
    private final Map<String, LocalDate> activeLoans;

    /**
     * Default constructor.
     */
    public Book() {
        this.bookId = "";
        this.title = "";
        this.author = "";
        this.category = "General";
        this.totalCopies = 1;
        this.availableCopies = 1;
        this.reservationQueue = new LinkedList<>();
        this.activeLoans = new HashMap<>();
    }

    /**
     * Parameterized constructor.
     */
    public Book(String bookId, String title, String author, String category, int totalCopies) throws InvalidBookException {
        if (bookId == null || bookId.trim().isEmpty()) {
            throw new InvalidBookException("Book ID cannot be null or empty.");
        }
        if (totalCopies <= 0) {
            throw new InvalidBookException("Total copies must be greater than zero.");
        }
        this.bookId = bookId.trim();
        this.title = title != null ? title.trim() : "Untitled";
        this.author = author != null ? author.trim() : "Unknown";
        this.category = category != null ? category.trim() : "General";
        this.totalCopies = totalCopies;
        this.availableCopies = totalCopies;
        this.reservationQueue = new LinkedList<>();
        this.activeLoans = new HashMap<>();
    }

    // Thread-safe synchronized transactions for shared inventory
    public synchronized boolean isAvailable() {
        return availableCopies > 0;
    }

    /**
     * Thread-safe method to issue a copy of this book.
     * @param memberId The borrowing member's ID.
     * @param dueDate The calculated due date.
     * @return true if successfully borrowed, false if no copies available.
     */
    public synchronized boolean borrowCopy(String memberId, LocalDate dueDate) {
        if (availableCopies > 0) {
            availableCopies--;
            activeLoans.put(memberId, dueDate);
            return true;
        }
        return false;
    }

    /**
     * Thread-safe method to return a copy of this book.
     * @param memberId The returning member's ID.
     * @return Due date if the book was borrowed by this member, null otherwise.
     */
    public synchronized LocalDate returnCopy(String memberId) {
        if (activeLoans.containsKey(memberId)) {
            LocalDate dueDate = activeLoans.remove(memberId);
            availableCopies++;
            return dueDate;
        }
        return null;
    }

    /**
     * Thread-safe method to place a reservation into the FIFO queue.
     * @param reservation The reservation request.
     * @return true if queued, false if duplicate reservation.
     */
    public synchronized boolean addReservation(Reservation reservation) {
        // Prevent duplicate pending reservation by same member
        for (Reservation res : reservationQueue) {
            if (res.getMemberId().equalsIgnoreCase(reservation.getMemberId()) 
                    && res.getStatus() == Reservation.Status.PENDING) {
                return false;
            }
        }
        return reservationQueue.offer(reservation);
    }

    /**
     * Thread-safe method to cancel an existing reservation by member ID.
     * Uses an Iterator to safely remove from the queue.
     */
    public synchronized boolean cancelReservation(String memberId) {
        Iterator<Reservation> iterator = reservationQueue.iterator();
        while (iterator.hasNext()) {
            Reservation res = iterator.next();
            if (res.getMemberId().equalsIgnoreCase(memberId) && res.getStatus() == Reservation.Status.PENDING) {
                res.setStatus(Reservation.Status.CANCELLED);
                iterator.remove();
                return true;
            }
        }
        return false;
    }

    /**
     * Polls the next reservation in the FIFO waitlist.
     */
    public synchronized Reservation pollNextReservation() {
        return reservationQueue.poll();
    }

    public synchronized Queue<Reservation> getReservationQueue() {
        return new LinkedList<>(reservationQueue);
    }

    public synchronized int getReservationCount() {
        return reservationQueue.size();
    }

    public synchronized Map<String, LocalDate> getActiveLoans() {
        return Collections.unmodifiableMap(activeLoans);
    }

    public synchronized LocalDate getDueDateForMember(String memberId) {
        return activeLoans.get(memberId);
    }

    // Getters and Setters
    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) throws InvalidBookException {
        if (bookId == null || bookId.trim().isEmpty()) {
            throw new InvalidBookException("Book ID cannot be empty.");
        }
        this.bookId = bookId.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title != null && !title.trim().isEmpty()) {
            this.title = title.trim();
        }
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        if (author != null && !author.trim().isEmpty()) {
            this.author = author.trim();
        }
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        if (category != null && !category.trim().isEmpty()) {
            this.category = category.trim();
        }
    }

    public synchronized int getTotalCopies() {
        return totalCopies;
    }

    public synchronized void setTotalCopies(int totalCopies) throws InvalidBookException {
        if (totalCopies <= 0) {
            throw new InvalidBookException("Total copies must be positive.");
        }
        int borrowedCount = this.totalCopies - this.availableCopies;
        if (totalCopies < borrowedCount) {
            throw new InvalidBookException("Cannot set total copies lower than currently borrowed copies (" + borrowedCount + ").");
        }
        this.availableCopies = totalCopies - borrowedCount;
        this.totalCopies = totalCopies;
    }

    public synchronized int getAvailableCopies() {
        return availableCopies;
    }

    @Override
    public int compareTo(Book other) {
        return this.bookId.compareToIgnoreCase(other.bookId);
    }

    @Override
    public String toString() {
        return String.format("ID: %-8s | Title: %-25s | Author: %-18s | Category: %-12s | Available: %2d/%-2d | Waitlist: %d",
                bookId, title, author, category, availableCopies, totalCopies, reservationQueue.size());
    }
}
