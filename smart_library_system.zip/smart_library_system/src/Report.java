import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Queue;

/**
 * Report generation engine for the Library Management System.
 * Demonstrates Collections traversal using Iterator and ListIterator,
 * Generics, formatted table generation, and data aggregation.
 */
public class Report {

    /**
     * Generates a comprehensive Circulation Report showing active loans.
     * Uses Iterator over collection data.
     */
    public static void generateCirculationReport(Library library) {
        System.out.println("\n=========================================================================================");
        System.out.println("                                  CIRCULATION REPORT                                     ");
        System.out.println("=========================================================================================");
        System.out.printf("%-10s | %-22s | %-12s | %-18s | %-12s | %-10s%n",
                "Book ID", "Title", "Member ID", "Member Name", "Due Date", "Status");
        System.out.println("-".repeat(89));

        int activeLoansCount = 0;
        int overdueCount = 0;
        LocalDate today = LocalDate.now();

        List<Book> booksList = new ArrayList<>(library.getAllBooks());
        Iterator<Book> bookIterator = booksList.iterator();

        while (bookIterator.hasNext()) {
            Book book = bookIterator.next();
            Map<String, LocalDate> activeLoans = book.getActiveLoans();

            for (Map.Entry<String, LocalDate> entry : activeLoans.entrySet()) {
                String memberId = entry.getKey();
                LocalDate dueDate = entry.getValue();
                Member member = library.findMember(memberId);
                String memberName = (member != null) ? member.getName() : "Unknown";

                boolean isOverdue = dueDate.isBefore(today);
                String status = isOverdue ? "OVERDUE (" + ChronoUnit.DAYS.between(dueDate, today) + "d)" : "On Time";

                if (isOverdue) overdueCount++;
                activeLoansCount++;

                System.out.printf("%-10s | %-22s | %-12s | %-18s | %-12s | %-10s%n",
                        book.getBookId(),
                        truncate(book.getTitle(), 22),
                        memberId,
                        truncate(memberName, 18),
                        dueDate,
                        status);
            }
        }

        if (activeLoansCount == 0) {
            System.out.println("  No active book loans currently on record.");
        }
        System.out.println("-".repeat(89));
        System.out.printf("Total Active Loans: %d | Overdue Loans: %d%n", activeLoansCount, overdueCount);
        System.out.println("=========================================================================================\n");
    }

    /**
     * Generates an Inventory Report showing all catalog items and stock levels.
     * Uses ListIterator to demonstrate bidirectional collection traversal.
     */
    public static void generateInventoryReport(Library library) {
        System.out.println("\n=========================================================================================");
        System.out.println("                                    INVENTORY REPORT                                     ");
        System.out.println("=========================================================================================");
        System.out.printf("%-8s | %-24s | %-18s | %-12s | %-7s | %-7s | %-7s%n",
                "ID", "Title", "Author", "Category", "Total", "Avail", "Issued");
        System.out.println("-".repeat(89));

        List<Book> bookList = new ArrayList<>(library.getAllBooks());
        ListIterator<Book> listIterator = bookList.listIterator();

        int totalTitles = 0;
        int grandTotalCopies = 0;
        int totalAvailable = 0;

        while (listIterator.hasNext()) {
            Book book = listIterator.next();
            totalTitles++;
            grandTotalCopies += book.getTotalCopies();
            totalAvailable += book.getAvailableCopies();
            int issued = book.getTotalCopies() - book.getAvailableCopies();

            System.out.printf("%-8s | %-24s | %-18s | %-12s | %-7d | %-7d | %-7d%n",
                    book.getBookId(),
                    truncate(book.getTitle(), 24),
                    truncate(book.getAuthor(), 18),
                    truncate(book.getCategory(), 12),
                    book.getTotalCopies(),
                    book.getAvailableCopies(),
                    issued);
        }

        if (totalTitles == 0) {
            System.out.println("  Library catalog is currently empty.");
        }
        System.out.println("-".repeat(89));
        System.out.printf("Total Titles: %d | Total Copies: %d | Total Available: %d | Total Issued: %d%n",
                totalTitles, grandTotalCopies, totalAvailable, (grandTotalCopies - totalAvailable));
        System.out.println("=========================================================================================\n");
    }

    /**
     * Generates a Fine Report showing members with outstanding dues.
     * Uses Iterator for member traversal.
     */
    public static void generateFineReport(Library library) {
        System.out.println("\n=========================================================================================");
        System.out.println("                                      FINE REPORT                                        ");
        System.out.println("=========================================================================================");
        System.out.printf("%-10s | %-22s | %-25s | %-12s | %-12s%n",
                "Member ID", "Member Name", "Email", "Phone", "Fine Due ($)");
        System.out.println("-".repeat(89));

        double totalOutstandingFine = 0.0;
        int membersWithFines = 0;

        List<Member> members = new ArrayList<>(library.getAllMembers());
        Iterator<Member> memberIterator = members.iterator();

        while (memberIterator.hasNext()) {
            Member member = memberIterator.next();
            if (member.getTotalFines() > 0) {
                membersWithFines++;
                totalOutstandingFine += member.getTotalFines();

                System.out.printf("%-10s | %-22s | %-25s | %-12s | $%-11.2f%n",
                        member.getId(),
                        truncate(member.getName(), 22),
                        truncate(member.getEmail(), 25),
                        member.getPhone(),
                        member.getTotalFines());
            }
        }

        if (membersWithFines == 0) {
            System.out.println("  No outstanding fines! All members are in good standing.");
        }
        System.out.println("-".repeat(89));
        System.out.printf("Members with Fines: %d | Total Outstanding Fines: $%.2f%n",
                membersWithFines, totalOutstandingFine);
        System.out.println("=========================================================================================\n");
    }

    /**
     * Generates a Reserved Books Report showing books with pending waitlist queues.
     * Demonstrates Queue traversal.
     */
    public static void generateReservedBooksReport(Library library) {
        System.out.println("\n=========================================================================================");
        System.out.println("                                 RESERVED BOOKS REPORT                                   ");
        System.out.println("=========================================================================================");
        System.out.printf("%-10s | %-24s | %-12s | %-10s | %-25s%n",
                "Book ID", "Title", "Queue Size", "Res ID", "Waiting Member");
        System.out.println("-".repeat(89));

        int totalReservations = 0;
        List<Book> books = new ArrayList<>(library.getAllBooks());

        for (Book book : books) {
            Queue<Reservation> queue = book.getReservationQueue();
            if (!queue.isEmpty()) {
                boolean first = true;
                for (Reservation res : queue) {
                    totalReservations++;
                    Member member = library.findMember(res.getMemberId());
                    String memberInfo = res.getMemberId() + (member != null ? " (" + member.getName() + ")" : "");

                    if (first) {
                        System.out.printf("%-10s | %-24s | %-12d | %-10s | %-25s%n",
                                book.getBookId(),
                                truncate(book.getTitle(), 24),
                                queue.size(),
                                res.getReservationId(),
                                truncate(memberInfo, 25));
                        first = false;
                    } else {
                        System.out.printf("%-10s | %-24s | %-12s | %-10s | %-25s%n",
                                "", "", "",
                                res.getReservationId(),
                                truncate(memberInfo, 25));
                    }
                }
            }
        }

        if (totalReservations == 0) {
            System.out.println("  No active reservations in the queue.");
        }
        System.out.println("-".repeat(89));
        System.out.printf("Total Books with Waitlists: %d | Total Active Queue Entries: %d%n",
                books.stream().filter(b -> b.getReservationCount() > 0).count(), totalReservations);
        System.out.println("=========================================================================================\n");
    }

    /**
     * Helper utility to safely truncate long strings for clean tabular presentation.
     */
    private static String truncate(String str, int maxLen) {
        if (str == null) return "";
        if (str.length() <= maxLen) return str;
        return str.substring(0, maxLen - 3) + "...";
    }
}
