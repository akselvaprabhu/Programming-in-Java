/**
 * Custom Exception thrown when member-related validation or operations fail.
 * Represents domain-specific error handling for library patrons and memberships.
 */
public class InvalidMemberException extends Exception {

    /**
     * Constructs a new InvalidMemberException with the specified detail message.
     * @param message Detailed reason for the exception.
     */
    public InvalidMemberException(String message) {
        super(message);
    }

    /**
     * Constructs a new InvalidMemberException with the specified message and cause.
     * @param message Detailed reason for the exception.
     * @param cause Underlying throwable cause.
     */
    public InvalidMemberException(String message, Throwable cause) {
        super(message, cause);
    }
}
