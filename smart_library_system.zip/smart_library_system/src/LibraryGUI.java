import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class LibraryGUI extends JFrame {
    private final Library library;
    private DefaultTableModel bookTableModel;
    private DefaultTableModel memberTableModel;
    private DefaultTableModel reservationTableModel;
    private DefaultTableModel reportTableModel;
    private JTable bookTable, memberTable, reservationTable, reportTable;
    private JTextArea transactionLogArea, notificationLogArea;
    private JProgressBar notificationProgressBar;
    private JLabel reportHeaderLabel;

    public LibraryGUI() {
        super("Smart Library Management, Reservation & Notification System");
        this.library = new Library();
        this.library.seedSampleData();
        initializeUI();
        refreshAllData();
    }

    private void initializeUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1050, 720);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(24, 43, 73));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel titleLabel = new JLabel("Smart Library Management System");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);

        JLabel subtitleLabel = new JLabel("Java JDK 17 Desktop GUI | Modern Applet Interface");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(new Color(180, 200, 230));

        headerPanel.add(titleLabel, BorderLayout.NORTH);
        headerPanel.add(subtitleLabel, BorderLayout.SOUTH);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabbedPane.addTab("  Books Catalog  ", createBooksPanel());
        tabbedPane.addTab("  Members Directory  ", createMembersPanel());
        tabbedPane.addTab("  Issue / Return  ", createTransactionsPanel());
        tabbedPane.addTab("  Reservations & Waitlist  ", createReservationsPanel());
        tabbedPane.addTab("  Reports & Analytics  ", createReportsPanel());
        tabbedPane.addTab("  Multithreaded Notifications  ", createNotificationsPanel());

        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.setBorder(BorderFactory.createEtchedBorder());
        JLabel statusLabel = new JLabel(" System Ready | Connected to Library Inventory & Reservation Queue");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        statusPanel.add(statusLabel);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(headerPanel, BorderLayout.NORTH);
        getContentPane().add(tabbedPane, BorderLayout.CENTER);
        getContentPane().add(statusPanel, BorderLayout.SOUTH);
    }
    private JPanel createBooksPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        JLabel searchLabel = new JLabel("Search Books:");
        searchLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        JTextField searchField = new JTextField(25);
        JButton searchBtn = new JButton("Search");
        JButton resetBtn = new JButton("Show All");

        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(resetBtn);

        String[] columns = {"Book ID", "Title", "Author", "Category", "Available Copies", "Total Copies", "Waitlist"};
        bookTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        bookTable = new JTable(bookTableModel);
        styleTable(bookTable);
        JScrollPane scrollPane = new JScrollPane(bookTable);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Manage Catalog"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField idField = new JTextField(8);
        JTextField titleField = new JTextField(15);
        JTextField authorField = new JTextField(12);
        JTextField categoryField = new JTextField(10);
        JTextField copiesField = new JTextField(5);

        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(new JLabel("Book ID:"), gbc);
        gbc.gridx = 1; formPanel.add(idField, gbc);
        gbc.gridx = 2; formPanel.add(new JLabel("Title:"), gbc);
        gbc.gridx = 3; formPanel.add(titleField, gbc);
        gbc.gridx = 4; formPanel.add(new JLabel("Author:"), gbc);
        gbc.gridx = 5; formPanel.add(authorField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Category:"), gbc);
        gbc.gridx = 1; formPanel.add(categoryField, gbc);
        gbc.gridx = 2; formPanel.add(new JLabel("Total Copies:"), gbc);
        gbc.gridx = 3; formPanel.add(copiesField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addBtn = new JButton("Add Book");
        JButton deleteBtn = new JButton("Delete Book");
        buttonPanel.add(addBtn);
        buttonPanel.add(deleteBtn);

        gbc.gridx = 4; gbc.gridy = 1; gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);

        searchBtn.addActionListener(e -> {
            String q = searchField.getText().trim();
            if (q.isEmpty()) refreshBooksTable();
            else displayBooksInTable(library.searchBooks(q));
        });

        resetBtn.addActionListener(e -> {
            searchField.setText("");
            refreshBooksTable();
        });

        addBtn.addActionListener(e -> {
            try {
                String id = idField.getText().trim();
                String title = titleField.getText().trim();
                String author = authorField.getText().trim();
                String cat = categoryField.getText().trim();
                int copies = Integer.parseInt(copiesField.getText().trim());

                Book book = new Book(id, title, author, cat, copies);
                library.addBook(book);
                refreshBooksTable();
                idField.setText(""); titleField.setText(""); authorField.setText(""); categoryField.setText(""); copiesField.setText("");
                JOptionPane.showMessageDialog(this, "Book '" + title + "' added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Copies must be a positive integer.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (InvalidBookException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Catalog Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        deleteBtn.addActionListener(e -> {
            int selectedRow = bookTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a book from the table to delete.", "Selection Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String bookId = (String) bookTableModel.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Delete book " + bookId + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    library.deleteBook(bookId);
                    refreshBooksTable();
                    JOptionPane.showMessageDialog(this, "Book deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (InvalidBookException ex) {
                    JOptionPane.showMessageDialog(this, ex.getMessage(), "Delete Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createMembersPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        String[] columns = {"Member ID", "Name", "Email", "Phone", "Borrowed / Limit", "Outstanding Fine ($)"};
        memberTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        memberTable = new JTable(memberTableModel);
        styleTable(memberTable);
        JScrollPane scrollPane = new JScrollPane(memberTable);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Register & Manage Members"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField idField = new JTextField(8);
        JTextField nameField = new JTextField(15);
        JTextField emailField = new JTextField(15);
        JTextField phoneField = new JTextField(10);
        JTextField limitField = new JTextField("3", 5);

        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(new JLabel("Member ID:"), gbc);
        gbc.gridx = 1; formPanel.add(idField, gbc);
        gbc.gridx = 2; formPanel.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 3; formPanel.add(nameField, gbc);
        gbc.gridx = 4; formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 5; formPanel.add(emailField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1; formPanel.add(phoneField, gbc);
        gbc.gridx = 2; formPanel.add(new JLabel("Borrow Limit:"), gbc);
        gbc.gridx = 3; formPanel.add(limitField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton registerBtn = new JButton("Register Member");
        JButton payFineBtn = new JButton("Pay Fine");
        buttonPanel.add(registerBtn);
        buttonPanel.add(payFineBtn);

        gbc.gridx = 4; gbc.gridy = 1; gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);

        registerBtn.addActionListener(e -> {
            try {
                String id = idField.getText().trim();
                String name = nameField.getText().trim();
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();
                int limit = Integer.parseInt(limitField.getText().trim());

                Member member = new Member(id, name, email, phone, limit);
                library.registerMember(member);
                refreshMembersTable();
                idField.setText(""); nameField.setText(""); emailField.setText(""); phoneField.setText("");
                JOptionPane.showMessageDialog(this, "Member '" + name + "' registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Borrow limit must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (InvalidMemberException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Registration Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        payFineBtn.addActionListener(e -> {
            int selectedRow = memberTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a member from the table.", "Selection Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String memberId = (String) memberTableModel.getValueAt(selectedRow, 0);
            Member member = library.findMember(memberId);
            if (member == null || member.getTotalFines() <= 0) {
                JOptionPane.showMessageDialog(this, "Member has no outstanding fines.", "Information", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String amountStr = JOptionPane.showInputDialog(this,
                    "Current Due: $" + String.format("%.2f", member.getTotalFines()) + "\nEnter payment amount ($):",
                    String.valueOf(member.getTotalFines()));
            if (amountStr != null && !amountStr.trim().isEmpty()) {
                try {
                    double amt = Double.parseDouble(amountStr.trim());
                    if (member.payFine(amt)) {
                        refreshMembersTable();
                        JOptionPane.showMessageDialog(this, "Payment of $" + String.format("%.2f", amt) + " processed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, "Invalid amount. Cannot exceed total fines.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid numeric amount.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }
    private JPanel createTransactionsPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel splitPanel = new JPanel(new GridLayout(1, 2, 20, 0));

        JPanel issuePanel = new JPanel(new GridBagLayout());
        issuePanel.setBorder(BorderFactory.createTitledBorder("Issue Book"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField issueBookIdField = new JTextField(12);
        JTextField issueMemberIdField = new JTextField(12);
        JTextField issueDaysField = new JTextField("14", 6);
        JButton issueBtn = new JButton("Confirm Issue");

        gbc.gridx = 0; gbc.gridy = 0; issuePanel.add(new JLabel("Book ID:"), gbc);
        gbc.gridx = 1; issuePanel.add(issueBookIdField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; issuePanel.add(new JLabel("Member ID:"), gbc);
        gbc.gridx = 1; issuePanel.add(issueMemberIdField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; issuePanel.add(new JLabel("Loan Days:"), gbc);
        gbc.gridx = 1; issuePanel.add(issueDaysField, gbc);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        issuePanel.add(issueBtn, gbc);

        JPanel returnPanel = new JPanel(new GridBagLayout());
        returnPanel.setBorder(BorderFactory.createTitledBorder("Return Book"));
        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.insets = new Insets(8, 8, 8, 8);
        gbc2.fill = GridBagConstraints.HORIZONTAL;

        JTextField returnBookIdField = new JTextField(12);
        JTextField returnMemberIdField = new JTextField(12);
        JButton returnBtn = new JButton("Confirm Return");

        gbc2.gridx = 0; gbc2.gridy = 0; returnPanel.add(new JLabel("Book ID:"), gbc2);
        gbc2.gridx = 1; returnPanel.add(returnBookIdField, gbc2);
        gbc2.gridx = 0; gbc2.gridy = 1; returnPanel.add(new JLabel("Member ID:"), gbc2);
        gbc2.gridx = 1; returnPanel.add(returnMemberIdField, gbc2);
        gbc2.gridx = 0; gbc2.gridy = 2; gbc2.gridwidth = 2;
        returnPanel.add(returnBtn, gbc2);

        splitPanel.add(issuePanel);
        splitPanel.add(returnPanel);

        JPanel logPanel = new JPanel(new BorderLayout(5, 5));
        logPanel.setBorder(BorderFactory.createTitledBorder("Transaction Activity Log"));
        transactionLogArea = new JTextArea(10, 50);
        transactionLogArea.setEditable(false);
        transactionLogArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logPanel.add(new JScrollPane(transactionLogArea), BorderLayout.CENTER);

        issueBtn.addActionListener(e -> {
            try {
                String bId = issueBookIdField.getText().trim();
                String mId = issueMemberIdField.getText().trim();
                int days = Integer.parseInt(issueDaysField.getText().trim());

                if (library.issueBook(bId, mId, days)) {
                    refreshAllData();
                    appendTransactionLog("ISSUED: Book '" + bId + "' to Member '" + mId + "' for " + days + " days.");
                    JOptionPane.showMessageDialog(this, "Book '" + bId + "' issued successfully to " + mId + "!", "Transaction Complete", JOptionPane.INFORMATION_MESSAGE);
                    issueBookIdField.setText(""); issueMemberIdField.setText("");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Loan days must be a number.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (InvalidBookException | InvalidMemberException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Issue Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        returnBtn.addActionListener(e -> {
            try {
                String bId = returnBookIdField.getText().trim();
                String mId = returnMemberIdField.getText().trim();

                double fine = library.returnBook(bId, mId);
                refreshAllData();
                appendTransactionLog("RETURNED: Book '" + bId + "' from Member '" + mId + "'. Accrued Fine: $" + String.format("%.2f", fine));

                if (fine > 0) {
                    JOptionPane.showMessageDialog(this, "Book returned successfully!\nOverdue fine charged: $" + String.format("%.2f", fine),
                            "Overdue Fine Applied", JOptionPane.WARNING_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Book returned successfully on time! No fines applied.", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
                returnBookIdField.setText(""); returnMemberIdField.setText("");
            } catch (InvalidBookException | InvalidMemberException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Return Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(splitPanel, BorderLayout.NORTH);
        panel.add(logPanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createReservationsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        String[] columns = {"Reservation ID", "Book ID", "Book Title", "Member ID", "Member Name", "Queue Position", "Status"};
        reservationTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        reservationTable = new JTable(reservationTableModel);
        styleTable(reservationTable);
        JScrollPane scrollPane = new JScrollPane(reservationTable);

        JPanel formPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Place / Cancel Hold on Unavailable Books"));

        JTextField bookIdField = new JTextField(8);
        JTextField memberIdField = new JTextField(8);
        JButton reserveBtn = new JButton("Place Reservation");
        JButton cancelBtn = new JButton("Cancel Reservation");

        formPanel.add(new JLabel("Book ID:"));
        formPanel.add(bookIdField);
        formPanel.add(new JLabel("Member ID:"));
        formPanel.add(memberIdField);
        formPanel.add(reserveBtn);
        formPanel.add(cancelBtn);

        reserveBtn.addActionListener(e -> {
            try {
                String bId = bookIdField.getText().trim();
                String mId = memberIdField.getText().trim();
                Reservation res = library.reserveBook(bId, mId);
                refreshAllData();
                appendTransactionLog("RESERVED: " + res.getReservationId() + " for Book " + bId + " by " + mId);
                JOptionPane.showMessageDialog(this, "Reservation confirmed!\nReservation ID: " + res.getReservationId(),
                        "Hold Placed", JOptionPane.INFORMATION_MESSAGE);
                bookIdField.setText(""); memberIdField.setText("");
            } catch (InvalidBookException | InvalidMemberException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Reservation Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelBtn.addActionListener(e -> {
            try {
                String bId = bookIdField.getText().trim();
                String mId = memberIdField.getText().trim();
                library.cancelReservation(bId, mId);
                refreshAllData();
                appendTransactionLog("CANCELLED RESERVATION: Book " + bId + " for " + mId);
                JOptionPane.showMessageDialog(this, "Reservation cancelled successfully.", "Cancelled", JOptionPane.INFORMATION_MESSAGE);
                bookIdField.setText(""); memberIdField.setText("");
            } catch (InvalidBookException | InvalidMemberException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Cancellation Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.SOUTH);
        return panel;
    }
    private JPanel createReportsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton circBtn = new JButton("Circulation Report");
        JButton invBtn = new JButton("Inventory Report");
        JButton fineBtn = new JButton("Fine Report");
        JButton resBtn = new JButton("Reserved Books Report");

        buttonPanel.add(circBtn);
        buttonPanel.add(invBtn);
        buttonPanel.add(fineBtn);
        buttonPanel.add(resBtn);

        reportHeaderLabel = new JLabel("Select a report type above to view real-time data", SwingConstants.CENTER);
        reportHeaderLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        reportHeaderLabel.setForeground(new Color(24, 43, 73));
        reportHeaderLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 10, 0));

        reportTableModel = new DefaultTableModel();
        reportTable = new JTable(reportTableModel);
        styleTable(reportTable);
        JScrollPane scrollPane = new JScrollPane(reportTable);

        circBtn.addActionListener(e -> loadCirculationReport());
        invBtn.addActionListener(e -> loadInventoryReport());
        fineBtn.addActionListener(e -> loadFineReport());
        resBtn.addActionListener(e -> loadReservedBooksReport());

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(reportHeaderLabel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(centerPanel, BorderLayout.CENTER);
        return panel;
    }

    private void loadCirculationReport() {
        reportHeaderLabel.setText("CIRCULATION REPORT - Active Book Loans & Due Dates");
        String[] cols = {"Book ID", "Title", "Member ID", "Member Name", "Due Date", "Status"};
        reportTableModel.setDataVector(new Object[][]{}, cols);

        LocalDate today = LocalDate.now();
        for (Book b : library.getAllBooks()) {
            for (Map.Entry<String, LocalDate> loan : b.getActiveLoans().entrySet()) {
                String memberId = loan.getKey();
                LocalDate dueDate = loan.getValue();
                Member m = library.findMember(memberId);
                String name = (m != null) ? m.getName() : "Unknown";
                boolean isOverdue = dueDate.isBefore(today);
                String status = isOverdue ? "OVERDUE (" + ChronoUnit.DAYS.between(dueDate, today) + "d)" : "On Time";
                reportTableModel.addRow(new Object[]{b.getBookId(), b.getTitle(), memberId, name, dueDate.toString(), status});
            }
        }
        styleTable(reportTable);
    }

    private void loadInventoryReport() {
        reportHeaderLabel.setText("INVENTORY REPORT - Catalog Statistics & Stock Levels");
        String[] cols = {"Book ID", "Title", "Author", "Category", "Total Copies", "Available", "Issued Copies"};
        reportTableModel.setDataVector(new Object[][]{}, cols);

        for (Book b : library.getAllBooks()) {
            int issued = b.getTotalCopies() - b.getAvailableCopies();
            reportTableModel.addRow(new Object[]{
                    b.getBookId(), b.getTitle(), b.getAuthor(), b.getCategory(), b.getTotalCopies(), b.getAvailableCopies(), issued
            });
        }
        styleTable(reportTable);
    }

    private void loadFineReport() {
        reportHeaderLabel.setText("FINE REPORT - Outstanding Dues by Member");
        String[] cols = {"Member ID", "Name", "Email", "Phone", "Outstanding Fine ($)"};
        reportTableModel.setDataVector(new Object[][]{}, cols);

        for (Member m : library.getAllMembers()) {
            if (m.getTotalFines() > 0) {
                reportTableModel.addRow(new Object[]{
                        m.getId(), m.getName(), m.getEmail(), m.getPhone(), String.format("$%.2f", m.getTotalFines())
                });
            }
        }
        styleTable(reportTable);
    }

    private void loadReservedBooksReport() {
        reportHeaderLabel.setText("RESERVED BOOKS REPORT - Active Waitlist Queues");
        String[] cols = {"Book ID", "Book Title", "Queue Position", "Reservation ID", "Waiting Member"};
        reportTableModel.setDataVector(new Object[][]{}, cols);

        for (Book b : library.getAllBooks()) {
            Queue<Reservation> q = b.getReservationQueue();
            int pos = 1;
            for (Reservation r : q) {
                Member m = library.findMember(r.getMemberId());
                String memberInfo = r.getMemberId() + (m != null ? " (" + m.getName() + ")" : "");
                reportTableModel.addRow(new Object[]{
                        b.getBookId(), b.getTitle(), "#" + pos++, r.getReservationId(), memberInfo
                });
            }
        }
        styleTable(reportTable);
    }

    private JPanel createNotificationsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton sendBtn = new JButton("Run Multithreaded Notification Dispatcher");
        sendBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));

        notificationProgressBar = new JProgressBar();
        notificationProgressBar.setPreferredSize(new Dimension(250, 25));
        notificationProgressBar.setStringPainted(true);
        notificationProgressBar.setString("Ready");

        topPanel.add(sendBtn);
        topPanel.add(notificationProgressBar);

        JPanel centerPanel = new JPanel(new BorderLayout(5, 5));
        centerPanel.setBorder(BorderFactory.createTitledBorder("Concurrent Worker Threads Output Stream"));

        notificationLogArea = new JTextArea();
        notificationLogArea.setEditable(false);
        notificationLogArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        notificationLogArea.setBackground(new Color(248, 249, 250));
        centerPanel.add(new JScrollPane(notificationLogArea), BorderLayout.CENTER);

        sendBtn.addActionListener(e -> {
            sendBtn.setEnabled(false);
            notificationProgressBar.setIndeterminate(true);
            notificationProgressBar.setString("Processing concurrent threads...");
            notificationLogArea.setText("");

            new Thread(() -> {
                appendNotificationLog("================================================================================");
                appendNotificationLog("         LAUNCHING CONCURRENT MULTITHREADED NOTIFICATION ENGINE                 ");
                appendNotificationLog("================================================================================");

                List<Notification> notificationBatch = new ArrayList<>();
                LocalDate today = LocalDate.now();

                for (Book book : library.getAllBooks()) {
                    for (Map.Entry<String, LocalDate> loan : book.getActiveLoans().entrySet()) {
                        String memberId = loan.getKey();
                        LocalDate dueDate = loan.getValue();
                        Member member = library.findMember(memberId);
                        if (member == null) continue;

                        if (today.isAfter(dueDate)) {
                            long overdueDays = ChronoUnit.DAYS.between(dueDate, today);
                            double fine = overdueDays * Library.DAILY_FINE_RATE;
                            notificationBatch.add(new OverdueNotification(
                                    member.getEmail(), member.getName(), book.getTitle(), overdueDays, fine));
                        } else {
                            notificationBatch.add(new DueDateNotification(
                                    member.getEmail(), member.getName(), book.getTitle(), dueDate));
                        }
                    }
                }

                if (notificationBatch.isEmpty()) {
                    appendNotificationLog("[INFO] No active loans requiring notification at this time.");
                } else {
                    List<Thread> workers = new ArrayList<>();
                    int idx = 1;

                    for (Notification notif : notificationBatch) {
                        int priority = (notif instanceof OverdueNotification) ? Thread.MAX_PRIORITY : Thread.NORM_PRIORITY;
                        int delay = (notif instanceof OverdueNotification) ? 120 : 250;
                        String threadName = "WorkerThread-" + (idx++);

                        Thread t = new Thread(() -> {
                            try {
                                Thread.sleep(delay);
                                synchronized (notificationLogArea) {
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(String.format("[%s | Priority: %d] Processing notification:%n", threadName, priority));
                                    sb.append(String.format("  [DISPATCHED] -> %s <%s>%n", notif.getRecipientName(), notif.getRecipientEmail()));
                                    sb.append(String.format("  [TYPE]        %s%n", notif.getNotificationType()));
                                    sb.append(String.format("  [BOOK]        '%s'%n", notif.getBookTitle()));
                                    if (notif instanceof OverdueNotification on) {
                                        sb.append(String.format("  [STATUS]      OVERDUE by %d days | Fine Due: $%.2f%n", on.getDaysOverdue(), on.getFineAmount()));
                                    } else if (notif instanceof DueDateNotification ddn) {
                                        sb.append(String.format("  [STATUS]      Due on %s (Reminder)%n", ddn.getDueDate()));
                                    }
                                    sb.append("  ").append("-".repeat(60));
                                    appendNotificationLog(sb.toString());
                                }
                            } catch (InterruptedException ex) {
                                Thread.currentThread().interrupt();
                            }
                        });
                        t.setPriority(priority);
                        workers.add(t);
                        t.start();
                    }

                    for (Thread w : workers) {
                        try {
                            w.join();
                        } catch (InterruptedException ex) {
                            Thread.currentThread().interrupt();
                        }
                    }
                    appendNotificationLog("================================================================================");
                    appendNotificationLog(String.format("All %d concurrent worker threads executed and joined successfully.", workers.size()));
                    appendNotificationLog("================================================================================");
                }

                SwingUtilities.invokeLater(() -> {
                    notificationProgressBar.setIndeterminate(false);
                    notificationProgressBar.setString("Completed (" + notificationBatch.size() + " Sent)");
                    sendBtn.setEnabled(true);
                });
            }).start();
        });

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(centerPanel, BorderLayout.CENTER);
        return panel;
    }

    private void refreshAllData() {
        refreshBooksTable();
        refreshMembersTable();
        refreshReservationsTable();
        loadCirculationReport();
    }

    private void refreshBooksTable() {
        displayBooksInTable(new ArrayList<>(library.getAllBooks()));
    }

    private void displayBooksInTable(List<Book> books) {
        bookTableModel.setRowCount(0);
        for (Book b : books) {
            bookTableModel.addRow(new Object[]{
                    b.getBookId(), b.getTitle(), b.getAuthor(), b.getCategory(), b.getAvailableCopies(), b.getTotalCopies(), b.getReservationCount()
            });
        }
    }

    private void refreshMembersTable() {
        memberTableModel.setRowCount(0);
        for (Member m : library.getAllMembers()) {
            memberTableModel.addRow(new Object[]{
                    m.getId(), m.getName(), m.getEmail(), m.getPhone(),
                    m.getBorrowedCount() + " / " + m.getMaxBorrowLimit(),
                    String.format("$%.2f", m.getTotalFines())
            });
        }
    }

    private void refreshReservationsTable() {
        reservationTableModel.setRowCount(0);
        for (Book b : library.getAllBooks()) {
            Queue<Reservation> q = b.getReservationQueue();
            int pos = 1;
            for (Reservation r : q) {
                Member m = library.findMember(r.getMemberId());
                String name = (m != null) ? m.getName() : "Unknown";
                reservationTableModel.addRow(new Object[]{
                        r.getReservationId(), b.getBookId(), b.getTitle(), r.getMemberId(), name, "#" + (pos++), r.getStatus()
                });
            }
        }
    }

    private void appendTransactionLog(String message) {
        SwingUtilities.invokeLater(() -> {
            transactionLogArea.append("[" + LocalDate.now() + "] " + message + "\n");
            transactionLogArea.setCaretPosition(transactionLogArea.getDocument().getLength());
        });
    }

    private void appendNotificationLog(String message) {
        SwingUtilities.invokeLater(() -> {
            notificationLogArea.append(message + "\n");
            notificationLogArea.setCaretPosition(notificationLogArea.getDocument().getLength());
        });
    }

    private void styleTable(JTable table) {
        table.setRowHeight(25);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.getTableHeader().setBackground(new Color(230, 235, 245));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            if (i == 0 || i >= 4) {
                table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            LibraryGUI gui = new LibraryGUI();
            gui.setVisible(true);
        });
    }
}